import {Component} from "react";

export default class StaffPage extends Component {
     constructor(props) {
        super(props);
    }

    render() {
        return (
            <p>OLA</p>
        );
    }
}