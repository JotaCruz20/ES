import React, { Component } from "react";
import { render } from "react-dom";
import Login from "./Login";

export default class App extends Component {
  constructor(props) {
    super(props);
  }

  render() {
    return (
      <div className="center">
        <Login />
      </div>
    );
  }
}

const appDiv = document.getElementById("staff");
render(<App />, appDiv);